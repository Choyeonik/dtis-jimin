// Fill in your real values here. This file is gitignored — safe to edit locally.

// "신청완료-알림" 채널 웹훅
export const DISCORD_WEBHOOK_URL_SUCCESS = "https://discord.com/api/webhooks/1550336925041168415/47F56R4BnEQ1XQYk_IuiCEXt_fphsEgB8Jfh_bfhxhzrKPkM-8w_849B--aGeaqWuoJU";
// "사용자-중지-알림" 채널 웹훅
export const DISCORD_WEBHOOK_URL_STOP = "https://discord.com/api/webhooks/1550559218145431574/N5F3Q1Vrr0_-pgKX6akRHVwKUIXHgdSjpLHZKY49AobONDTrfa8M8psfv9kt3KDXiZg5";
export const KAKAO_ACCESS_TOKEN = "";

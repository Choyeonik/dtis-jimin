// Copy this file to config.js and fill in your own values.
// config.js is gitignored — never commit real tokens/URLs.

export const DISCORD_WEBHOOK_URL = "https://discordapp.com/api/webhooks/1550336925041168415/47F56R4BnEQ1XQYk_IuiCEXt_fphsEgB8Jfh_bfhxhzrKPkM-8w_849B--aGeaqWuoJU";
export const KAKAO_ACCESS_TOKEN = "";
